/*
 *	Formation jQuery
 *	TP 3  : Parcourir et modifier la DOM*/

// Encapsulation :
(function ($) {

	// Au chargement de la page :
	$(document).ready(function(){
		
		/*
			DEM0
		*/
		// var $li = $("li") ;
		// alert($li.text()) ;  
		// alert($li.html()) ;
		// alert($li.length) ;
	
		/*
			EXEMPLE :
			Numéroter les tableaux avec les méthode .each() et .prepend()
		*/
		
		// Ensemble des éléments "caption"
		var $captions = $("caption") ;
		
		// On les parcourt un à un
		$captions.each(function(i){
		
			// Noeud courant :
			var $captionCourant =  $(this) ;
		
			// Numéro du noeud (i commence à 0)
			var num = i+1 ;
		
			// On rajoute le numéro au début du noeud 
			$captionCourant.prepend(num+". ") ;
			
		});
		
		/*
			EXERCICE 1
			Dans les cellules qui ont la classe «provisoire», ajouter le lien suivant :
			<a href="#" title="Provisoire">(p)<a>
		*/
		
		// cellules qui ont la classe provisoire
		var $cellulesProvisoiresNonVides = $("td.provisoire") ;
		
		// Ajout du lien après ces cellules
		$cellulesProvisoiresNonVides.append("<a href=\"#\" title=\"Provisoire\">(p)</a>") ;
		
		
		/*
			EXERCICE 2
			Dans les cellules qui sont vides ou bien ne contiennent que des espaces, écrire n.d. et ajouter la classe "non-defini" 	
		*/
			
		// Sélectionne toutes les cases
		var $cellules = $("td") ;
		
		// ( Déclaration préalable d'une variable si on veut créer un objet avec les cases vides )
		// var $casesVides  ;
		
		// Les parcourt une à une pour vérifier la condition
		$("td").each(function(){
		
			// Dans la boucle .each(), "this" renvoie vers le noeud courant, $(this) en fait un objet jQuery
			var $td = $(this) ;
			
			// Sans argument, la méthode .text() renvoie le contenu textuel du noeud
			var content = $td.text() ;
			
			// La fonction .trim() permet de supprimer les espaces superflus
			if($.trim(content)=="") {
				
				// Texte et classe de la cellule (chainé) :
				$td.html("n.d.").addClass("non-defini") ;
				
				// ( Récupération des vides dans une objet jQuery )
				// $casesVides = $td.add($casesVides) ;
			}
			
		});
				
		//	VARIANTE avec la méthode .filter() 
		//	Filter admet une fonction comme paramètre
		/*  
		var $casesVides =  $("td").filter(function() {
			var content = $(this).text() ;
			var bool = ($.trim(content)=="") ;
			return bool ;
		})
		$casesVides.html("n.d.").addClass("non-defini") ;
		*/
		
		/*
			EXERCICE 3
			Avant le nom des départements qui comprennent des cellules non-définies, ajouter le lien suivant :
			<a href=\"#\" title=\"Incomplet\">(i)</a>
		*/
		
		/* Version 1 : en utilisant les fonctions de parcours "classiques" .closest() et .find() */
		
		/* Sélection des cases vides */ 
		var $casesVides = $(".non-defini") ;
		
		/* Sélection du premier parent de la case de type <tr> */ 
		var $lignesCasesVides = $casesVides.closest("tr") ;
		
		/* Sélection du premier enfant de la ligne */ 
		var $NomLignesCasesVides = $lignesCasesVides.find("td:first-child") ;
		
		/* Ajout du texte */ 
		$NomLignesCasesVides.append(" <a href=\"#\" title=\"Incomplet\">(i)</a>") ;
		
		// /* Chainé : */ $("tbody td:empty").closest("tr").find(":first-child").append(" <a href=\"#\" title=\"Incomplet\">(i)</a>") ;
		
		/* Version 2 : en utilisant les fonctions de parcours .parent() et .children() */
		 // $("tbody td:empty").parent().children(":first-child").append(" <a href=\"#\" title=\"Incomplet\">(i)</a>") ;

		/* Version 3 : en utilisant directement la fonction de parcourt prevAll ou siblings */
		// $("tbody td:empty").siblings(":first-child").append(" <a href=\"#\" title=\"Incomplet\">(i)</a>") ;
		
		/*
			EXERCICE 3
			Dans le corps des tableaux, remplacer la première cellule de chaque ligne par une cellule de type «titre» (balise <th> au lieu de <td>).
			On conserve l'attribut "headers" de la cellule
		*/
		
		// Sélection des premières cellules de chaques lignes que l'on parcourt une à une
 		$("body tr td:first-child").each(function(){
		
			// Noeud courant que l'on va remplacer (objet jquery)
			var $ancien = $(this) ;
			
			// Attribut header que l'on veut conserver (chaîne de caractères)
			var attributHeader = $ancien.attr("headers") ;
			
			// Contenu texte que l'on veut conserver
			var contenu = $ancien.html()
			
			// Cellule de remplacement : balise th, le même texte, le même attribut
			var $nouveau = $("<th>"+contenu+"</th>").attr("headers",attributHeader) ;
			
			// Méthode replaceWith pour remplacer 
			$ancien.replaceWith($nouveau) ;
			
		});
/*
		// Variante : on récupère tous les attributs de l'ancien noeud, sans les connaître a priori	
		$("tbody tr td:first-child").each(function(){
		
			// Noeud courant que l'on va remplacer (objet jquery)
			var $ancien = $(this) ;
			
			var $nouveau = $("<th>"+$ancien.html()+"</th>") ;
			
			// On récupères les attributs l'objet javascript natif
			var attributes = $ancien.get(0).attributes ;
			
			// On parcourt ses attributs, par exemple avec la méthodes $.each() de jquery
			$.each(attributes,function(){
				$nouveau.attr(this.nodeName,this.textContent) ;
			})
			
			// Méthode replaceWith pour remplacer
			$ancien.replaceWith($nouveau) ;
		});
*/		
		
		/*
			EXERCICE 4
			Trier chacun des tableaux selon l'ordre alphabétique des départements. 
		*/
		
		// Sélection des tbody (coeur des tableaux) que l'on parcourt un à un
		$("tbody").each(function(){
			
			// Noeud courant
			var $tbody = $(this) ;
			
			// Capture des lignes du tableau courant (sauf la dernière qui correspond à la région)
			var $lignesDepartement = $tbody.children("tr").not(":last-child") ;
			
			// Tri des lignes
			// C'est l'objet jquery qui est trié, pour l'instant le DOM n'est pas modifié (donc aucun changement n'est affiché)
			$lignesDepartement.sort(function(ligneA,ligneB) {
				// Tri par ordre alphabétique selon le texte de la première case de chaque ligne
				var valeurA = $(ligneA).children(":first").text() ;
				var valeurB = $(ligneB).children(":first").text() ;
				return valeurA > valeurB  ?  1 :  -1 ;
			})
				 
			// On insère les lignes triées au début du tableau 
			$lignesDepartement.prependTo($tbody) ;
			
		});	
/* 

		// Variante :
		// Si on trie aussi la ligne correspondant à la région
 		
		// On boucle sur les tbody qu'on va trier un par un
		$("tbody").each(function(){
			var $tbody = $(this) ;
			$tbody
				// Capture des lignes du tableau
				.children("tr")
				// Tri selon la première case de la ligne
				 .sort(function(ligneA,ligneB) {
					// Fonction de tri
					var valeurA = $(ligneA).children(":first").text() ;
					var valeurB = $(ligneB).children(":first").text() ;
					return valeurA > valeurB  ?  1 :  -1 ;
				 })
				 // Les lignes sont ajoutée à $tBody dans l’ordre de tri
				.appendTo($tbody) ;
		}); 
*/

	}); // Fin des instructions envoyées au chargement de la page
	
})(jQuery); // Fin de l'encapsulation
