/*
 *	Formation jQuery
 *	TP 1 : S�lection et style*/

// Encapsulation :
(function ($) {

	// Au chargement de la page :
	$(document).ready(function(){
	
		/*
			EXEMPLE :
			Aligner � gauche la premi�re ligne du <thead>
		*/
		
		// S�lection des 1eres cases avec le s�lecteur CSS "thead th:first-child"
		var $premieresCasesThead = $("thead th:first-child") ;
		
		// On applique le style
		$premieresCasesThead.css("text-align","left") ;
		
		/*
			EXERCICE 1 :
			Dans chaque tableau, mettre la derni�re ligne en italique
		*/
		
		// On s�lectionne la derni�re ligne de chaque tableau :
		// On pr�cise l'anc�tre tbdody pour ne pas mettre l'ent�te en italique
		var $dernieresLignes = $("tbody tr:last-child") ;
		
		// On lui attribue la propri�t� css voulue :
		$dernieresLignes.css("font-style", "italic"); 
		
		// On aurait pu tout �crire d'un coup :
		// $("tbody tr:last-child").css("font-style", "italic"); 

		/*
			EXERCICE 2 :
			Dans le corps des tableaux, attribuer � la premi�re cellule de chaque ligne le style suivant :

				{
					color: #555555;
					font-weight: bold;
					text-align: left;
				}			
			
			Utiliser pour cela le format JSON.
			NB : dans l'ennonc� les styles sont �crits avec une syntaxe CSS, qui n'est pas celle que vous devez utiliser
			
		*/
		
		// On s�l�ctionne la premi�re case de chaque ligne 
		var $premieresCases = $("tr td:first-child") ;
		
		// Style au format jSon :
		var jSonStyle = {
			textAlign:"left",
			fontWeight:"bold",
			color:"#555"
		} ;
		
		// On attribut le style aux premi�res cases de chaque lignes 
		$premieresCases.css(jSonStyle);
		
		// On aurait pu tout �crire d'un coup
		/* 		
		$("tbody tr td:first-child").css({
			textAlign:"left",
			fontWeight:"bold",
			color:"#555"
		}); 
		*/
		
		/*
			EXERCICE 3 :
			Attribuer � la ligne ayant l'identifiant reg24ref la couleur de fond #FBEC88
		*/
		
		// Ligne ayant l'identifiant reg24ref
		$basseNormandie = $("#reg24ref") ;
		
		// M�thode css pour modifier le style
		$basseNormandie.css("background-color","#FBEC88");
		
		/*
			EXERCICE 4 :
			Attribuer aux lignes paires des tableaux (dans le tbody) la couleur de fond  #e8e8e8
			Sauf si elles ont l'identifiant "#reg24ref"
		*/
		
		// Lignes paires du tbody qui ont identifiant #reg24ref
		var $mesLignes = $("table tbody>tr:odd:not(#reg24ref)") ;
		// Modification du style
		$mesLignes.css("background-color", "#e8e8e8") ;
		
		// On aurait pu tout �crire d'un coup :
		// $("table tbody tr:odd:not(#reg24ref)").css("background-color", "#e8e8e8") ;
		
		// Variantes pour tenir compte de chaque tableau :
		// $("table tbody tr:nth-child(even):not(#reg24ref)").css("background-color", "#e8e8e8") ;
		
	}); // Fin des instructions envoy�es au chargement de la page
	
})(jQuery); // Fin de l'encapsulation
