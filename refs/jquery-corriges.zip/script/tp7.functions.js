/*
 *	Formation jQuery
 *	TP 7 : Fonctions
 *  Script pour la d�claration des fonctions
 * 	Inspir� d'un plugin d'Alen Grakalic (http://cssglobe.com/post/1695/easiest-tooltip-and-image-preview-using-jquery)
*/

// Encapsulation :
(function ($) {

	// Surcharge des m�thodes de jQuery  : 
	$.fn.extend({
		
		// M�thode pour activer une item dans le menu des onglets
		activeOnglet: function(options){
			
			// Configuration par d�faut
			var confDefault = {
				classeActive : "active",
				valeurRetour : false 
			}
			
			// Surcharge de la configuration
			var conf = $.extend(
				confDefault,
				options
			) ;	
			
			// This renvoie directement le groupe de noeuds auquel la m�thode s'applique
			var $listeOnglets = this ;
			
			$listeOnglets.click(function(){
			
				// Onglet cliqu� : 
				var $onglet = $(this) ;

				// On enl�ve la classe sur tous les items
				$listeOnglets.removeClass(conf.classeActive) ;

				// On met la classe active sur l'item qui a �t� cliqu�
				$onglet.addClass(conf.classeActive) ;

				// Ex�cution du clique ?
				return conf.valeurRetour ;
					
			})
			
			// On active le premier onglet
			$listeOnglets.eq(0).click() ;
			
			// M�thode chainable (i.e. return this)
			return $listeOnglets ;
			
		}, // Fin de la m�thode activeOnglet()
		
		// M�thode afficher le tableau quand on clique sur le tableau
		afficheTableau: function(options) {
			
			// Configuration par d�faut
			var confDefault = {
				valeurRetour : false 
			}
			
			// Surcharge de la configuration
			var conf = $.extend(
				confDefault,
				options
			) ;	
			
			// This renvoie directement le groupe de noeuds auquel la m�thode s'applique
			var $listeOnglets = this ;
			
			// Initialisation : on stocke les tableaux dans une variable
			var $tables = $("table").hide() ;
			
			// Activation de l'onglet quand on clique dessus
			$listeOnglets.click(function(){
		
				// Onglet courant 
				var $onglet = $(this) ;
				
				// Le s�lecteur du tableau � afficher est donn� par l'attribut href du lien cliqu�
				var selecteur = $onglet.attr("href") ;
				
				// On cache tous les tableaux
				$tables.hide() ;
				
				// J'affiche le tableau qui v�rifie le s�lecteur 
				$tables.filter(selecteur).show() ;
		
				
				// Ex�cution du clique ?
				return conf.valeurRetour ;
				
			})
			
			// On active le premier onglet
			$listeOnglets.eq(0).click() ;
			
			// M�thode chainable (i.e. return this)
			return $listeOnglets ;
			
		}, // Fin de la m�thode afficheTableau()
		
		// D�claration de la fonction infobulle
		infobulle: function(options){
		
			// Configuration par d�faut
			var confDefault = {
					position:"absolute",
					x : 0,
					y :14,
					fadeSpeed : 50,
					id : "mytooltip",
					css : {
						opacity:1,
						background:"#ffb",
						color:"#444",
						boxShadow : "2px 2px 4px rgba(0,0,0,0.4)",
						border:"1px solid #666",
						padding:"5px 10px",
						position:"absolute"
					}	
			}

			// Surcharge de la css si besoin 
			if(options && options.css) {
				options.css = $.extend(
					confDefault.css,
					options.css,
					{position:"absolute"} // C'est pas n�gociable
				)
			}
			// Surcharge de la configuration : 
			var conf = $.extend(
				confDefault,
				options
			) ;	

			// Initialisation : position "relative" sur <body> pour pouvoir d�placer l'infobulle
			$("body").css("position","relative") ;
			
			// Initialisation : cr�ation de l'infobulle
			var $infobulle = $("<p></p>").attr("id",conf.id).css(conf.css) ;
		
			// Variable title d�clar�e en amont
			var title = "" ;
			
			// Syntaxe "return this" pour pouvoir cha�ner la fonction avec d'autres fonctions
			return this.each(function(){
				var $a = $(this) ;
				// Evenements "la souris arrive sur le lien" et "la souris quitte le lien"
				$a.hover(
					// Quand la souris arrive sur le lien on fait appara�tre l'infobulle
					// L'infobulle contient l'attribut "titre" du lien
					function(e){								  
						title = $a.attr("title");
						$a.attr("title","") ;
						$infobulle
							.hide()
							.text(title)
							.appendTo("body") 
							.css("top",(e.pageY + conf.y) + "px")
							.css("left",(e.pageX + conf.x) + "px")
							.fadeIn(conf.fadeSpeed);		
					},
					// Quand la souris quitte le lien on fait dispara�tre l'infobulle
					// L'attribut "titre" du lien prend le contenu de ce qui �tait dans l'infobulle
					function(){
						$a.attr("title",title) ;		
						$infobulle.detach() ;
					}
				);	
				// Evenement "la souris se d�place au dessus du lien
				// On fait bouger l'infobulle en m�me temps que le lien
				$a.mousemove(function(e){
					$infobulle
						.css("top",(e.pageY + conf.y) + "px")
						.css("left",(e.pageX + conf.x) + "px");
				});				
			});				
		}, // Fin de la fonction infobulle

		// M�thode pour afficher la t�te de colonne et la t�te de ligne dans l'attribute Title de la cellule
		titreCellule: function(options) {
			
			// Configuration par d�faut
			var confDefault = {
				separateur : " : " ,
				unite : " %" 
			}
			
			// Surcharge de la configuration
			var conf = $.extend(
				confDefault,
				options
			) ;	
			
			// Ex�cution et retour
			return this.each(function(i){
			
				var $td = $(this) ;
				
				// Texte de la celulle
				var tdTexte = $td.text() ;
							
				// Texte de la tete de ligne
				var teteLigneTexte = $td.closest("tr").children(":first").text() ;
				
				// Texte de la tete de colonne
				var teteColonneTexte = $td.closest("table").find("#"+$td.attr("headers")).text() ;
				
				// Texte � afficher 
				var title = teteLigneTexte+" "+teteColonneTexte+conf.separateur+tdTexte+conf.unite ;
				
				// Cr�ation ou modification de l'attribut title
				$td.attr("title",title) ;
			
			});
		}, // Fin de la fonction titreCellule

		// Menu d'onglets (fusion des m�thodes activeOnglet et afficheTableau)
		menuOnglet: function(options) {
			
			// Surcharge de la configuration
			var conf = $.extend({
					classeActive : "active",
					selecteurCache : "table",
					valeurRetour : false 
				},
				options
			) ;	
			
			// This renvoie directement le groupe de noeuds auquel la m�thode s'applique
			var $listeOnglets = this ;
			
			// Initialisation : on stocke les tableaux dans une variable
			var $tables = $(conf.selecteurCache).hide() ;
			
			// Activation de l'onglet quand on clique dessus
			$listeOnglets.click(function(){
		
				// Onglet courant 
				var $onglet = $(this) ;
				
				// Le s�lecteur du tableau � afficher est donn� par l'attribut href du lien cliqu�
				var selecteur = $onglet.attr("href") ;
				
				// On enl�ve la classe sur tous les items
				$listeOnglets.removeClass(conf.classeActive) ;

				// On met la classe active sur l'item qui a �t� cliqu�
				$onglet.addClass(conf.classeActive) ;

				//  On cache tous les tableaux et affiche le tableau qui v�rifie le s�lecteur 
				$tables.hide().filter(selecteur).show() ;
		
				// Ex�cution du clique ?
				return conf.valeurRetour ;
				
			})
			
			// On active le premier onglet
			$listeOnglets.eq(0).click() ;
			
			// M�thode chainable (i.e. return this)
			return $listeOnglets ;
			
		} // Fin de la m�thode afficheTableau()
		
	}); // Fin de la surcharge des fonctions 
	
})(jQuery); // Fin de l'encapsulation
