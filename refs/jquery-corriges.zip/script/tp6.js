/*
 *	Formation jQuery
 *	TP 4 bis : Plugins
*/

// Encapsulation :
(function ($) {

	// Au chargement de la page :	
	$(document).ready(function() {

		/*	
			DEMO
		*/
		
		// Echec du chargement
		// $("<div></div>").load("/not-here.php",function(data, status) {
			// if (status == "error") alert("Erreur !") ;
			// else alert(data)  ;
        // }); 
		
		/*	
			EXEMPLE
			Chargement d'un tableau
		*/
		
		// Bouton cliquable
		var $exemple = $("input#exemple") ;
		
		// Adresse du fichier charg�
		var fichierExemple = "xml/reg43.xml" ;
		
		// Emplacement du tableau
		var $conteneurTableau = $("#tableau") ;
		
		// �v�nement clique
		$exemple.click(function(){
			
			// M�thode .load() : charge directement le contenu du fichier dans l'objet auquel la m�thode s'applique
			$conteneurTableau.load(fichierExemple,function(data,status){
			
				// Param�tre data : contenu du fichier charg�
				// alert(data) ;
				// Param�tre status : vaut erreur si le fichier n'a pas �t� charg�
				if(status=="error") {
				
					// Message d'erreur
					$conteneurTableau.html("<p>Impossible de charger le fichier "+fichierExemple+"</p>") ;
					
					// Interruption du script
					return ;
				}
				// Message ajout� dans le tableau
				$conteneurTableau.append("<p>Charg&eacute; &agrave; partir du fichier "+fichierExemple+"</p>") ;
				
			});
		});
		
		/*	
			EXERCICE 1
			Affichage du tableau correspondant � l'option s�lectionn�e quand on clique sur le bouton �voir les d�partements�.
			Les addresses des fichiers des tableaux sont dans les attributs value des options.
			Le bouton cliquable se retrouve gr�ce � l'identifiant valide et la liste de s�lection avec l'identifiant regions.
		*/	
		
		// Liste de s�lection
		var $select = $("select#regions") ;
		
		// Bouton pour valider
		var $valide = $("input#valide") ;
		
		// Emplacement du tableau
		var $conteneurTableau = $("#tableau") ;
		
		// �v�nement clique
		$valide.click(function(){
			
			// Option s�lectionn�e dans la liste de s�lection :
			// -> pseudo �l�ment :selected
			// -> la m�thode .eq(0) assure qu'on n'a qu'un seul noeud jquery dans l'objet
			var $optionSelectionne =  $select.find("option:selected").eq(0) ;
			
			// L'attribut value de l'option contient l'adresse du fichier que l'on veut charger
			var fichier = $optionSelectionne.attr("value") ;

			// M�thode .load() : charge directement le contenu du fichier dans l'objet auquel la m�thode s'applique
			$conteneurTableau.load(fichier,function(data,status){
			
				// Param�tre status : vaut erreur si le fichier n'a pas �t� charg�
				if(status=="error") {
					$conteneurTableau.html("<p>Impossible de charger le fichier "+fichier+"</p>") ;
					return ;
				}
			});
		});
		
		/*	
			EXERCICE 2
			Recr�er la liste de s�lection � partir du fichier xml/regions.xml. 
			Les options g�n�r�es � partir du xml auront comme attribut value le code de la r�gion (regid).
		*/
		
		// On commence par d�sactiver la m�thode "click" pour le bouton de validation
		$valide.unbind("click") ;
		
		// Fichier des r�gions
		var fichierRegions = "xml/regions.xml" ;
		var fichierDeps = "xml/departements.xml" ;
		
		// Pour ne pas charger les fichiers
		// fichierRegions = fichierDeps = "fichier-qui-n-existe-pas" ;
		
		// Emplacement du tableau
		var $conteneurTableau = $("#tableau") ;
		
		// Liste de s�lection				
		var $select = $("select#regions") ;
		
		// Bouton cliquable 
		var $valide = $("input#valide") ;
		
		// On charge le fichier dans un objet anonyme (pas de r�utilisation possible)
		// --> On r�cup�rera le contenu du fichier grace au param�tre data
		$("<div></div>").load(fichierRegions,function(data,status){
			
			// Si le fichier n'est pas charg�, interruption des instructions
			if(status=="error") {
				// $conteneurTableau.html("<p>Impossible de charger le fichier "+fichier+"</p>") ;
				return ;
			}
			
			// Vide la bo�te de s�lection
			$select.empty() ;
			
			// On cr�e un objet jquery avec le contenu xml charg�
			var $data = $(data) ;
			
			// Le xml est parcouru de la m�me fa�on qu'un groupe de noeud html
			// --> on cherche l'ensemble des noeuds dont la balise est r�gion*
			var $regions = $data.find("region") ;
			
			// Pour chaque r�gion
			$regions.each(function(){
				
				// Ligne du xml
				var $regionXml = $(this) ;
				
				// Initialisation d'une nouvelle option pour cette r�gion
				var $option = $("<option></option>");
				
				// Nom de la r�gion : contenu texte de la balise "nom" :
				var nomRegion = $regionXml.find("nom").text() ;
				$option.text(nomRegion) ;

				// Code de la r�gion : valeur de l'attribut regid
				var codeRegion =  $regionXml.attr("regid") ;
				$option.attr("value",codeRegion) ;
				
				// On rajoute l'option dans notre liste de s�lection
				$select.append($option) ;			
			});
		});
		
		/*
			EXERCICE 3
			Charger le fichier xml/departements.xml.
			Quand on clique sur le bouton �voir les d�partements�, un tableau est g�n�r� avec uniquement les d�partements de la r�gion s�lectionn�e.
		*/
	
		// On charge le fichier dans un objet anonyme (pas de r�utilisation possible)
		// --> On r�cup�rera le contenu du fichier grace au param�tre data
		$("<div></div>").load(fichierDeps,function(data,status){
			
			// On cr�e un objet jquery avec le contenu xml charg�
			var $depXml = $(data) ;
				
			//�v�nement clique
			$valide.click(function(){
				
				// Option s�lectionn�e dans la liste de s�lection :
				var $optionSelectionne =  $select.find("option:selected").eq(0) ;
				
				// Identifiant et nom de la r�gion
				var regid = $optionSelectionne.attr("value") ;
				var regNom = $optionSelectionne.text() ;
				
				// S�lection des d�partements dans la r�gion choisies
				// -> d�rtement dont l'attribut regid vaut le code de la r�gion
				var $afficheDep = $depXml.find("departement[regid="+regid+"]") ;
				
				// Si aucun d�partement
				if ($afficheDep.length==0) {
					alert("aucun departement trouve pour la region "+regNom+" ("+regid+")");
				}
				
				// On cr�e un nouveau tableau
				var $nouveauTableau = $("<table><thead><tr><th>D&eacute;partement</th><th>Code</th><th>Chef-lieu</th></thead></table>") ;
				
				// identifiant du nouveau tableau
				$nouveauTableau.attr("id","reg"+regid) ;
				
				// Corps du tableau 
				var $tbody = $("<tbody></tbody>") ;
				
				// Caption : le nom la r�gion
				$nouveauTableau.prepend("<caption>"+regNom+"</caption>");
				
				// Parcourt les d�partement de la r�gion pour ajouter des lignes dans le corps du tableau
				$afficheDep.each(function(i){
					
					// Noeud courant : le d�partement
					var $dep = $(this) ;
					
					// Identifiant (code) du d�partement : dans l'attribut regId
					var depid = $dep.attr("depid") ;
					
					// Nom : contenu de la valise "nom"
					var depNom  =  $dep.find("nom").text() ;
					
					// Chef lieu : dans la balise "cheflieu", attribut regid
					var chefLieuId = $dep.find("cheflieu").attr("comid") ;
					
					// balise "cheflieu", contenu textuel
					var chefLieuNom = $dep.find("cheflieu").text() ;
					
					// Insertion d'une nouvelle ligne dans le tbody
					$tbody.append("<tr><th>"+depNom+"</th><td>"+depid+"</td><td>"+chefLieuNom+" ("+chefLieuId+") </td></tr>") ;
				
				});
				
				// Insertion du tbody dans le tableau
				$nouveauTableau.append($tbody) ;
				
				// Mise en place du tableau dans le contenueur du tableau
				$conteneurTableau.html($nouveauTableau) ;
				
				// Ne pas ex�cuter le clique
				return false ;
			});
		});
		
	}); // Fin des instructions envoy�es au chargement de la page
	
})(jQuery); // Fin de l'encapsulation
