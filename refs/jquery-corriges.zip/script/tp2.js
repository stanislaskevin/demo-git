/*
 *	Formation jQuery
 *	TP 2 : Attributs, classes, contenus texte et html*/

// Encapsulation :
(function ($) {

	// Au chargement de la page :
	$(document).ready(function(){
	
		/*
			EXEMPLE
			Attribuer aux dernières lignes de chaque tableau la classe region-reference.
		*/
		
		// Sélection de la dernière ligne de chaque tableau
		var $derniereLigne = $("tbody tr:last-child");
		
		// On applique la méthode .addClass() à notre sélection
		$derniereLigne.addClass("region-reference");
		
		// /* Chainage : */ $("tbody tr:last-child").addClass("region-reference");
	
		/*
			EXERCICE 1
			Mettre un attribut title valant "Provisoire" aux cellules qui ont la classe provisoire.
		*/
		
		// Cellules avec la classe provisoire
		var $cellulesProvisoires = $("td.provisoire") ;
		
		// Méthode attr pour modifier un attribut
		$cellulesProvisoires.attr("title","Provisoire") ;

		// /* Chainage : */ $("td.provisoire").attr("title","Provisoire");
		
		/*
			EXERCICE 2
			Dans les cellules vides, écrire « n.d » et ajouter la classe non-defini.
		*/
		
		// Cellules vides
		var $cellulesVides = $("td:empty") ;
		
		// Ajout de la classe "non-defini"
		$cellulesVides.addClass("non-defini")
		
		// Contenu texte "n.d."
		$cellulesVides.text("n.d.")
		
		// /* Chainage : */ $("td:empty").addClass("non-defini").text("n.d.") ;
				
		/*
			EXERCICE 3
			Mettre la classe non-significatif aux cellules dont l'attribut title contient "non significatif"
		*/
		
		// Cellules dont l'attribut rel contient : non-significatif
		var $nonSignigicatifs = $("td[title*='non significatif']") ;
		
		// Ajout de la classe non-significatif
		$nonSignigicatifs.addClass("non-significatif") ;
		
		// On aurait pu chainer
		// $("td[title*='non significatif']").addClass("non-significatif") ;
		
		/*
			EXERCICE 4
			Récupérer le contenu texte du lien ayant l'identifiant id-ligne-active.
			Ce contenu est l'identifiant de la ligne à laquelle vous devez mettre la classe class-ligne-active.
			A la place du code, mettre le nom de la région active dans le lien ayant l'identifiant id-ligne-active.
		*/
		
		// Lien ayant l'identifiant "id-ligne-active"
		var $lienLigneActive = $("a#id-ligne-active") ;

		// Identidiant de la ligne active
		var id = $lienLigneActive.text() ;
		
		// Ligne active
		var $ligneActive = $("tr#"+id) ;
		
		// Ajout de la classe class-ligne-active
		$ligneActive.addClass("class-ligne-active") ; 		
		
		// Case contenant le nom de la région
		var $caseNomRegion = $("tr#"+id+" th:first-child") ;
		
		// Nom de la région
		var nomRegion = $caseNomRegion.text() ;
		
		// Nom de la région dans le lien ayant l'identifiant "id-ligne-active"
		$lienLigneActive.text(nomRegion);

	}); // Fin des instructions envoyées au chargement de la page
	
})(jQuery); // Fin de l'encapsulation
