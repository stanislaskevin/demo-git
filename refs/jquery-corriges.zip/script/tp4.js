/*
 *	Formation jQuery
 *	TP 4 : �v�nements*/

// Encapsulation :
(function ($) {

	// Au chargement de la page :
	$(document).ready(function(){
	
		/*
			EXEMPLE 
			Classe "active" sur les items cliqu�s dans le menu par onglet
		*/
		
		// Variables contenant l'ensemble des liens du menu par onglet :
		var $ongletItems = $(".onglets a") ;
		
		// Fonction d�clench�es quand on clique sur l'un de ces items
		$ongletItems.click(function(){
			
			// On enl�ve la classe sur tous les items
			$ongletItems.removeClass("active") ;
			
			// On met la classe active sur l'item qui a �t� cliqu�
			$(this).addClass("active") ;
			
			// Annule l'action par d�faut
			return false ;
			
		});
	
		/*
			EXERCICE 1
			Cacher les tableaux.
			Quand on clique sur un onglet, le tableau li� appara�t.
			Le cas �ch�ant, les autres tableaux disparaissent.
			Astuce :
			$cible.css("display","none") cache un �l�ment et $cible.css("display","block") le remontre (pour un �l�ment de type bloc).
		*/
		
		// Je stocke mes tableaux et je les cache
		$tables = $("table").css("display","none") ;
		
		// D�clencher un �v�nement quand on clique sur un item		
		$ongletItems.click(function() {
		
			// Lien cliqu�
			var $clicked = $(this) ;
		
			// Je cache � nouveau mes tableaux
			$tables.css("display","none") ;
			
			// Le s�lecteur du tableau � afficher est donn� par l'attribut href du lien cliqu�
			selecteur = $clicked.attr("href") ;
			
			// J'affiche le tableau qui v�rifie le s�lecteur 
			$tables.filter(selecteur).css("display","block") ;
			
			// cha�ner toutes ces instructions 
			// $tables.css("display","none").filter($(this).attr("href")).css("display","block") ;
			
			// J'annule l'action pour ne pas modifer l'url
			return false ;
		});
		
		// Afficher par d�faut le premier tableau en simulant un clique sur le premier item
		$ongletItems.eq(0).click() ;
		
		/*
			EXERCICE 2
			Dans le conteneur (�div#conteneur�), ajouter l'�l�ment suivant :
			<div id="loupe"></div>
			Masqu� par d�faut, cet �l�ment appara�t quand on survole une cellule. Il affiche alors le contenu de la cellule.		
		*/
		
		// Je cr�e ma loupe et je l'ins�re cach�e dans le conteneur
		var $loupe = $("<div id=\"loupe\"></div>").css("display","none").appendTo($("#conteneur"));
		
		// Action d�clench�e quand on survole une cellule
		$("td").hover(
			// La souris arrive sur la cellule, j'affiche la loupe avec le contenu texte de la cellule
			function(){
				$loupe.css("display","block").text($(this).text());
			},
			// La souris quitte la cellule, je masque la loupe
			function(){
				$loupe.css("display","none");
			}
		)
		
		/*
			EXERCICE 3
			Quand une cellule est survol�e, les cellules de la m�me ligne et de la m�me colonne prennent la classe on.
			La cellule survol�e prend la classe active.
			Astuce :
			On retrouve les cellules d'une m�me colonne gr�ce � leur attribut headers. 
			En effet, sa valeur est l'identifiant de la t�te de la colonne.
		*/
		
		// Je boucle sur les tables pour �viter de griser plusieurs tableaux � la fois
		$("table").each(function(){

			var $table = $(this) ;
			
			// Survol d'une cellule
			$table.find("td").hover(
				function(){
					
					// Initialisation 
					var $td = $(this) ;
					
					// Attribut headers de la cellule (<=>identifiant la tete de colonne)
					var headers = $td.attr("headers") ;
					
					// On grise tous les �l�ments de la ligne
					var $memeLigne = $td.closest("tr").children() ;
					$memeLigne.addClass("on") ;
					
					// On grise tous les �l�ments de la colonne
					var $memeColonne = $table.find("[headers="+headers+"]") ;
					$memeColonne.addClass("on") ;
					
					// On grise la tete de colonne
					var $teteColonne = $table.find("#"+headers) ;
					$teteColonne.addClass("on") ;
					
					// La cellule prend la classe "active"
					$td.addClass("active") ;
					
				},
				function(){
					$table.find("*").removeClass("active").removeClass("on") ;
				}
			)
			
		});
		
	}); // Fin des instructions envoy�es au chargement de la page
	
})(jQuery); // Fin de l'encapsulation
